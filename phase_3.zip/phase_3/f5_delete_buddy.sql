USE DEEPdiver;

DELETE FROM dive_buddy 
WHERE diver_ID = 2 AND buddy_ID = 1;	
