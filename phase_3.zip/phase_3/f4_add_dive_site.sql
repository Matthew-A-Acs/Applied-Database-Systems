USE DEEPdiver;

INSERT INTO dive_site VALUES
(11,
'This is one of the most unique dive sites in the world where you have the chance to watch Tiger Sharks swimming around in their natural habitat. 
The spot is roughly 20 miles off the coast of West End. You can also see here lemon sharks, huge groupers and snappers. 
Site is quite shallow, 8 to 10 m deep, and divers are comfortably kneeling down on a sandy bottom, observing tiger sharks (some females reach up to 4,5m long). 
The trip there takes a full day.',
'West End',
'Bahamas',
'Tiger Beach',
'26.5900,-79.0800',
'Sand Bed'
);