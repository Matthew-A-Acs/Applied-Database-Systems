USE DEEPdiver;

INSERT INTO dive VALUES
(9,
15,
'Stormy',
'00:52:00',
'Air',
'2022-03-20',
78,
82,
25,
'I love to dive the nursery',
10,
5
);

INSERT INTO fauna_seen VALUES
('Chelonia mydas',
9,
'Sea turtles love to come to the nursery :)'
);

INSERT INTO flora_seen VALUES
('Acropora cervicornis',
9,
'All of the coral look the same...'
);