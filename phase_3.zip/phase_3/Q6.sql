Use DEEPdiver;

SELECT S.name, S.coordinates
FROM dive_site S, dive D, fauna_seen F
WHERE F.species = 'Chelonia mydas' AND F.dive_ID = D.dive_ID AND D.site_ID = S.site_ID;