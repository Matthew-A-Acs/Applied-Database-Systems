-----------------------------------------------------------------
Assignment by Matthew Acs (Z23536012) and Richard Acs (Z23536011)
-----------------------------------------------------------------

This ZIP doccument contains the report and code for the assignment.
The code is seperated into several different doccuments.

-----------------------------------------------------------------

1. deep_diver_setup.sql - creates the database tables and inserts the data
2. f1_register_user.sql - demonstrates user registration functionality
3. f2_log_dive.sql - demonstrates dive log functionality
4. f3_add_equipment_owned.sql - demonstrates adding equipment owned
5. f4_add_dive_site.sql - demonstrates adding a dive site to the databse
6. f5_delete_buddy.sql - demonstrates removing a buddy record
7. Q1.sql - first query
8. Q2.sql - second query
9. Q3.sql - third query
10. Q4.sql - forth query
11. Q5.sql - fifth query
12. Q6.sql - sixth query
13. Q7.sql - seventh query
14. Q8.sql - eighth query
15. Q9.sql - ninth query
16. Q10.sql - tenth query

-----------------------------------------------------------------

Please run the code in the order specified above to obtain the same results as in the PDF report.