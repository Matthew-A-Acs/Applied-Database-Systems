USE DEEPdiver;

INSERT INTO equipment_owned VALUES
(7,
5,
'2022-03-20',
990,
'2022-03-20',
'The HUD computer is super cool! I feel like Iron Man.'
);