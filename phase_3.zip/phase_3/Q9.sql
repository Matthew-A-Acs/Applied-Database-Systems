Use DEEPdiver;

SELECT S.name, A.common_name
FROM dive_site S, fauna_seen F, dive D, fauna A
WHERE S.site_ID = D.site_ID AND D.dive_ID = F.dive_ID 
AND F.species = A.species AND A.food_rating >= (SELECT MAX(A2.food_rating)
												FROM fauna A2);