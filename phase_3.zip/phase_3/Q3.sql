Use DEEPdiver;

SELECT E.name, E.type
FROM user S, equipment_owned O, equipment E
WHERE S.diver_ID = O.diver_ID AND O.equipment_ID = E.equipment_ID 
AND S.diver_ID IN (	SELECT S2.diver_ID
				FROM user S2, dive D, fauna_seen F
				WHERE S2.diver_ID = D.diver_ID AND D.dive_ID = F.dive_ID AND F.species = 'Chelonia mydas');