Use DEEPdiver;

SELECT U1.first_name
FROM user U1, user U2, dive_buddy B, user_certification C, certification T 
WHERE U1.diver_ID = B.diver_ID AND B.buddy_ID = U2.diver_ID AND U2.diver_ID = C.diver_ID AND C.certification_ID = T.certification_ID AND T.name = 'Night Diving';