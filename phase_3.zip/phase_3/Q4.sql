Use DEEPdiver;

SELECT C.name
FROM dive_center C, user U, dive D
WHERE U.center_ID = C.center_ID AND D.diver_ID = U.diver_ID
								AND D.depth >= (SELECT MAX(D2.depth)
												FROM dive D2);