Use DEEPdiver;

SELECT D.name, C.name, O.price
FROM dive_center D, certifications_offered O, certification C
Where D.center_ID = O.center_ID AND O.certification_ID = C.certification_ID AND
C.level = 'Open Water' AND O.price <= (SELECT MIN(O2.price)
										FROM certifications_offered O2, certification C2
										WHERE C2.level = 'Open Water' AND C2.certification_ID = O2.certification_ID);