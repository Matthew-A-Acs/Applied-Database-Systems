Use DEEPdiver;

SELECT U.first_name
FROM user U, dive_buddy B, user U2
WHERE U.diver_ID = B.diver_ID AND B.buddy_ID = U2.diver_ID
AND U2.year_of_first_dive <= all (SELECT U3.year_of_first_dive
								FROM user U3);