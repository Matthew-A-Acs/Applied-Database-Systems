Use DEEPdiver;

SELECT C.name
FROM dive_center C, certifications_offered O
WHERE C.center_ID = O.center_ID
GROUP BY C.center_ID
HAVING AVG(O.price) <= ALL (SELECT AVG(O2.price)
							FROM dive_center C2, certifications_offered O2
							WHERE C2.center_ID = O2.center_ID
							GROUP BY C2.center_ID);