Use DEEPdiver;

SELECT E.type
FROM equipment E, equipment_owned O, user u
WHERE u.diver_ID = O.diver_ID AND O.equipment_ID = E.equipment_ID AND U.level = 'Open Water'
GROUP BY E.type
HAVING COUNT(*) >= ALL (SELECT COUNT(*)
					FROM equipment E2, equipment_owned O2, user u2
					WHERE u2.diver_ID = O2.diver_ID AND O2.equipment_ID = E2.equipment_ID AND U2.level = 'Open Water'
					GROUP BY E2.type);