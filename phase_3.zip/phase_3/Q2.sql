Use DEEPdiver;

SELECT S.name, S.coordinates
FROM dive_site S, dive D
Where S.site_ID = D.site_ID AND D.water_conditions = 'calm'
GROUP BY S.site_ID
HAVING COUNT(*) >= ALL (SELECT COUNT(*)
						FROM dive_site S2, dive D2
						Where S2.site_ID = D2.site_ID AND D2.water_conditions = 'calm'
						GROUP BY S2.site_ID);