USE DEEPdiver;

INSERT INTO user VALUES
(6,
'female',
'718-712-9662',
'United States',
'Junior Open Water',
'Florida', 
'33431',
'Boca Raton',
'2296 NW 36th St',
'izaacs@gmail.com',
'Iza',
'Acs',
"2011-12-10",
2022,
'Diving is very cool',
1
);