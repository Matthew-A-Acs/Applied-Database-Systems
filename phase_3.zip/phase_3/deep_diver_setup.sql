DROP DATABASE IF EXISTS DEEPdiver;

CREATE DATABASE DEEPdiver;

USE DEEPdiver;

CREATE TABLE `Fauna` (
	`species` VARCHAR(255) NOT NULL,
	`common_name` VARCHAR(255) NOT NULL,
	`food_rating` INT NOT NULL,
	`description` TEXT NOT NULL,
	`habitat` VARCHAR(255) NOT NULL,
	`hunting_status` BOOLEAN NOT NULL,
	PRIMARY KEY (`species`)
);

CREATE TABLE `Dive` (
	`dive_ID` INT NOT NULL ,
	`dive_number` INT NOT NULL,
	`water_conditions` TEXT,
	`bottom_time` TIME,
	`gas` VARCHAR(255),
	`date` DATE NOT NULL,
	`water_temperature` INT,
	`air_temperature` INT,
	`depth` INT,
	`comments` TEXT,
	`site_ID` INT NOT NULL,
	`diver_ID` INT NOT NULL,
	PRIMARY KEY (`dive_ID`)
);

CREATE TABLE `Fauna_seen` (
	`species` VARCHAR(255) NOT NULL,
	`dive_ID` INT NOT NULL,
	`comments` TEXT NOT NULL,
	PRIMARY KEY (`species`,`dive_ID`)
);

CREATE TABLE `Dive_site` (
	`site_ID` INT NOT NULL ,
	`description` TEXT NOT NULL,
	`city` VARCHAR(255) NOT NULL,
	`country` VARCHAR(255) NOT NULL,
	`name` VARCHAR(255) NOT NULL,
	`coordinates` VARCHAR(255) NOT NULL,
	`type` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`site_ID`)
);

CREATE TABLE `Dive_center` (
	`center_ID` INT NOT NULL,
	`name` VARCHAR(255) NOT NULL,
	`state` VARCHAR(255) NOT NULL,
	`city` VARCHAR(255) NOT NULL,
	`address` VARCHAR(255) NOT NULL,
	`zip` VARCHAR(255) NOT NULL,
	`phone` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`center_ID`)
);

CREATE TABLE `User` (
	`diver_ID` INT NOT NULL,
	`gender` VARCHAR(255) NOT NULL,
	`phone` VARCHAR(255) NOT NULL,
	`country` VARCHAR(255) NOT NULL,
	`level` VARCHAR(255) NOT NULL,
	`state` VARCHAR(255) NOT NULL,
	`zip` VARCHAR(255) NOT NULL,
	`city` VARCHAR(255) NOT NULL,
	`address` VARCHAR(255) NOT NULL,
	`email` VARCHAR(255) NOT NULL,
	`first_name` VARCHAR(255) NOT NULL,
	`last_name` VARCHAR(255) NOT NULL,
	`birthday` DATE NOT NULL,
	`year_of_first_dive` INT NOT NULL,
	`bio` TEXT NOT NULL,
	`center_ID` INT NOT NULL,
	PRIMARY KEY (`diver_ID`)
);

CREATE TABLE `Equipment` (
	`equipment_ID` INT NOT NULL,
	`manufacturer` VARCHAR(255) NOT NULL,
	`name` VARCHAR(255) NOT NULL,
	`type` VARCHAR(255) NOT NULL,
	`description` TEXT NOT NULL,
	PRIMARY KEY (`equipment_ID`)
);

CREATE TABLE `Certification` (
	`certification_ID` INT NOT NULL,
	`name` VARCHAR(255) NOT NULL,
	`level` VARCHAR(255) NOT NULL,
	`certifier` VARCHAR(255) NOT NULL,
	`description` TEXT NOT NULL,
	PRIMARY KEY (`certification_ID`)
);

CREATE TABLE `Flora` (
	`species` VARCHAR(255) NOT NULL,
	`common_name` VARCHAR(255) NOT NULL,
	`description` TEXT NOT NULL,
	`habitat` VARCHAR(255) NOT NULL,
	PRIMARY KEY (`species`)
);

CREATE TABLE `Flora_seen` (
	`species` VARCHAR(255) NOT NULL,
	`dive_ID` INT NOT NULL,
	`comments` TEXT NOT NULL,
	PRIMARY KEY (`species`,`dive_ID`)
);

CREATE TABLE `Certifications_offered` (
	`center_ID` INT NOT NULL,
	`certification_ID` INT NOT NULL,
	`price` INT NOT NULL,
	PRIMARY KEY (`center_ID`,`certification_ID`)
);

CREATE TABLE `User_certification` (
	`diver_ID` INT NOT NULL,
	`certification_ID` INT NOT NULL,
	`date_recieved` DATE NOT NULL,
	`certification_number` INT NOT NULL,
	PRIMARY KEY (`diver_ID`,`certification_ID`)
);

CREATE TABLE `Equipment_owned` (
	`equipment_ID` INT NOT NULL,
	`diver_ID` INT NOT NULL,
	`date_purchased` DATE NOT NULL,
	`price` INT NOT NULL,
	`last_maintained` DATE NOT NULL,
	`comments` TEXT NOT NULL,
	PRIMARY KEY (`equipment_ID`,`diver_ID`)
);

CREATE TABLE `Dive_buddy` (
	`diver_ID` INT NOT NULL,
	`buddy_ID` INT NOT NULL,
	`year_since` INT NOT NULL,
	PRIMARY KEY (`diver_ID`,`buddy_ID`)
);

ALTER TABLE `Dive` ADD CONSTRAINT `Dive_fk0` FOREIGN KEY (`site_ID`) REFERENCES `Dive_site`(`site_ID`);

ALTER TABLE `Dive` ADD CONSTRAINT `Dive_fk1` FOREIGN KEY (`diver_ID`) REFERENCES `User`(`diver_ID`);

ALTER TABLE `Fauna_seen` ADD CONSTRAINT `Fauna_seen_fk0` FOREIGN KEY (`species`) REFERENCES `Fauna`(`species`);

ALTER TABLE `Fauna_seen` ADD CONSTRAINT `Fauna_seen_fk1` FOREIGN KEY (`dive_ID`) REFERENCES `Dive`(`dive_ID`);

ALTER TABLE `User` ADD CONSTRAINT `User_fk0` FOREIGN KEY (`center_ID`) REFERENCES `Dive_center`(`center_ID`);

ALTER TABLE `Flora_seen` ADD CONSTRAINT `Flora_seen_fk0` FOREIGN KEY (`species`) REFERENCES `Flora`(`species`);

ALTER TABLE `Flora_seen` ADD CONSTRAINT `Flora_seen_fk1` FOREIGN KEY (`dive_ID`) REFERENCES `Dive`(`dive_ID`);

ALTER TABLE `Certifications_offered` ADD CONSTRAINT `Certifications_offered_fk0` FOREIGN KEY (`center_ID`) REFERENCES `Dive_center`(`center_ID`);

ALTER TABLE `Certifications_offered` ADD CONSTRAINT `Certifications_offered_fk1` FOREIGN KEY (`certification_ID`) REFERENCES `Certification`(`certification_ID`);

ALTER TABLE `User_certification` ADD CONSTRAINT `User_certification_fk0` FOREIGN KEY (`diver_ID`) REFERENCES `User`(`diver_ID`);

ALTER TABLE `User_certification` ADD CONSTRAINT `User_certification_fk1` FOREIGN KEY (`certification_ID`) REFERENCES `Certification`(`certification_ID`);

ALTER TABLE `Equipment_owned` ADD CONSTRAINT `Equipment_owned_fk0` FOREIGN KEY (`equipment_ID`) REFERENCES `Equipment`(`equipment_ID`);

ALTER TABLE `Equipment_owned` ADD CONSTRAINT `Equipment_owned_fk1` FOREIGN KEY (`diver_ID`) REFERENCES `User`(`diver_ID`);

ALTER TABLE `Dive_buddy` ADD CONSTRAINT `Dive_buddy_fk0` FOREIGN KEY (`diver_ID`) REFERENCES `User`(`diver_ID`);

ALTER TABLE `Dive_buddy` ADD CONSTRAINT `Dive_buddy_fk1` FOREIGN KEY (`buddy_ID`) REFERENCES `User`(`diver_ID`);

INSERT INTO fauna VALUES
('Lachnolaimus maximus',
'Hogfish',
5,
'The hogfish (Lachnolaimus maximus) (known as boquinete, doncella de pluma or pez perro in Mexico[3]) is a species of wrasse native to the Western Atlantic Ocean, living in a range from Nova Scotia, Canada, to northern South America, including the Gulf of Mexico.[4] This species occurs around reefs, especially preferring areas with plentiful gorgonians. It is a carnivore which feeds on molluscs, as well as crabs and sea urchins.[2] This species is currently the only known member of its genus.[2]',
'Reef',
true),
('Pterois volitans',
'Red Lionfish',
3,
'The red lionfish (Pterois volitans) is a venomous coral reef fish in the family Scorpaenidae, order Scorpaeniformes. It is mainly native to the Indo-Pacific region, but has become an invasive species in the Caribbean Sea, as well as along the East Coast of the United States and East Mediterranean and also found in Brazil at Fernando de Noronha.[2]',
'Reef',
true),
('Chelonia mydas',
'Green Sea Turtle',
0,
'The green sea turtle (Chelonia mydas), also known as the green turtle, black (sea) turtle or Pacific green turtle,[4] is a species of large sea turtle of the family Cheloniidae. It is the only species in the genus Chelonia.[5] Its range extends throughout tropical and subtropical seas around the world, with two distinct populations in the Atlantic and Pacific Oceans, but it is also found in the Indian Ocean.[6][7] The common name refers to the usually green fat found beneath its carapace, not to the color of its carapace, which is olive to black.',
'Reef',
false),
('Seriola dumerili',
'Greater Amberjack',
3,
'The greater amberjack (Seriola dumerili), also known as the allied kingfish, great amberfish, greater yellowtail, jenny lind, purplish amberjack, reef donkey, rock salmon, sailors choice, yellowtail, and yellow trevally, is a species of predatory ray-finned fish in the family Carangidae, the jacks and pompanos. It is found in temperate, subtropical, and tropical seas around the world. It is a popular quarry species for recreational fisheries and is important in commercial fisheries. It is the largest species in the family Carangidae.',
'Open ocean',
true),
('Sphyraena barracuda',
'Great Barracuda',
3,
'Sphyraena barracuda, commonly known as the great barracuda, is a species of barracuda: large, predatory ray-finned fish found in subtropical oceans around the world.',
'Reef',
true),
('Panulirus argus',
'Caribbean Spiny Lobster',
4,
'Panulirus argus, the Caribbean spiny lobster, is a species of spiny
lobster that lives on reefs and in mangrove swamps in the western
Atlantic Ocean.',
'Reef',
true),
('Ginglymostoma cirratum',
'Nurse Shark',
0,
'The nurse shark (Ginglymostoma cirratum) is an elasmobranch fish in
the family Ginglymostomatidae. They are robust and able to tolerate
capture, handling, and tagging extremely well.[4] As inoffensive as
nurse sharks may appear, they are ranked fourth in documented shark
bites on humans,[5] likely due to incautious behavior by divers on
account of the nurse sharks slow, sedentary nature.',
'Reef',
false),
('Epinephelus itajara',
'Atlantic Goliath Grouper',
5,
'The Atlantic goliath grouper or itajara (Epinephelus itajara),
formerly known as the jewfish,[3][4] is a saltwater fish of the
grouper family and one of the largest species of bony fish. The
species can be found in the west ranging from northeastern Florida,
south throughout the Gulf of Mexico and the Caribbean Sea, and along
South America to Brazil. In the east the species ranges West Africa
from Senegal to Cabinda. The species has been observed at depths
ranging from 1 to 100 meters (3 to 328 feet).[1]',
'Wreck',
false),
('Pomacanthus paru',
'French Angelfish',
0,
'The French angelfish (Pomacanthus paru) is a species of marine
ray-finned fish, a marine angelfish belonging to the family
Pomacanthidae. It occurs in the Western Atlantic Ocean.',
'Reef',
false),
('Octopus briareus',
'Caribbean Reef Octopus',
0,
'The Caribbean reef octopus (Octopus briareus) is a coral reef marine
animal. It has eight long arms that vary in length and diameter. The
mantle is large and chunky in comparison (up to 60 cm long). This
species is difficult to describe because it changes color and texture
to blend into its surroundings, using specialised skin cells known as
chromatophores. Its color range is very large; it can change from
crimson to green, and bumpy to smooth.',
'Reef',
false);

INSERT INTO flora VALUES
('Sargassum natans',
'Seaweed',
'Sargassum is a genus of brown (class Phaeophyceae) macroalgae (seaweed) in the order Fucales. Numerous species are distributed throughout the temperate and tropical oceans of the world, where they generally inhabit shallow water and coral reefs, and the genus is widely known for its planktonic (free-floating) species. Most species within the class Phaeophyceae are predominantly cold-water organisms that benefit from nutrients upwelling, but the genus Sargassum appears to be an exception.[1] Any number of the normally benthic species may take on a planktonic, often pelagic existence after being removed from reefs during rough weather; however, two species (S. natans and S. fluitans) have become holopelagic—reproducing vegetatively and never attaching to the seafloor during their lifecycles. The Atlantic Oceans Sargasso Sea was named after the algae, as it hosts a large amount of Sargassum.[2]',
'Ocean surface'),
('Halodule wrightii',
'Shoalweed',
'Halodule wrightii is an aquatic plant in the Cymodoceaceae family.[3] It is referred to by the common names shoal grass or shoalweed, and is a plant species native to seacoasts of some of the warmer oceans of the world. H. wrightii is an herb growing in salt-water marshes in intertidal regions, often submerged at high tide but emergent at low tide.[4]',
'Grassbed'),
('Thalassia testudinum',
'Turtlegrass',
'Thalassia testudinum, commonly known as turtlegrass,[3] is a species of marine seagrass. It forms meadows in shallow sandy or muddy locations in the Caribbean Sea and the Gulf of Mexico.[4] Turtle grass and other seagrasses form meadows which are important habitats and feeding grounds. The grass is eaten by turtles and herbivorous fish, supports many epiphytes, and provides habitat for juvenile fish and many invertebrate taxa.',
'Grassbed'),
('Avicennia germinans',
'Black Mangrove',
'Avicennia germinans, the black mangrove,[2] is a shrub or small tree growing up to 12 meters (39 feet) in the acanthus family, Acanthaceae. It grows in tropical and subtropical regions of the Americas, on both the Atlantic and Pacific Coasts, and on the Atlantic Coast of tropical Africa, where it thrives on the sandy and muddy shores where seawater reaches. It is common throughout coastal areas of Texas and Florida, and ranges as far north as southern Louisiana and coastal Georgia in the United States. Like many other mangrove species, it reproduces by vivipary. Seeds are encased in a fruit, which reveals the germinated seedling when it falls into the water. Unlike other mangrove species, it does not grow on prop roots, but possesses pneumatophores that allow its roots to breathe even when submerged. It is a hardy species and expels absorbed salt mainly from its leathery leaves. The name "black mangrove" refers to the color of the trunk and heartwood. The leaves often appear whitish from the salt excreted at night and on cloudy days. It is often found in its native range with the red mangrove (Rhizophora mangle) and the white mangrove (Laguncularia racemosa). White mangroves grow inland from black mangroves, which themselves grow inland from red mangroves. The three species work together to stabilize the shoreline, provide buffers from storm surges, trap debris and detritus brought in by tides, and provide feeding, breeding, and nursery grounds for a great variety of fish, shellfish, birds, and other wildlife.',
'Estuary'),
('Gorgonia ventalina',
'Purple Sea Fan',
'Gorgonia ventalina, the common sea fan and purple sea fan, is a species of sea fan, an octocoral in the family Gorgoniidae. It is found in the western Atlantic Ocean and the Caribbean Sea.',
'Reef'),
('Xestospongia muta',
'Giant Barrel Sponge',
'The giant barrel sponge (Xestospongia muta) is the largest species of
sponge found growing on Caribbean coral reefs. It is common at depths
greater than 10 metres (33 ft) down to 120 metres (390 ft) and can
reach a diameter of 1.8 metres (6 feet). It is typically brownish-red
to brownish-gray in color, with a hard or stony texture.',
'Reef'),
('Acropora cervicornis',
'Staghorn Coral ',
'Staghorn coral forms antler-like branches growing in tangled dense
thickets. The surface is covered with small, protruding round cups. It
is brown to yellow-brown with a pale tip on the end of each branch.
The tips are quite delicate and easily broken. Found 10-160 feet (3-49
m) below the surface in protected clear water, colonies cover large
areas of the reef.',
'Reef'),
('Diploria strigosa',
'Common Brain Coral',
'Colonies form smooth plates or hemispherical domes at depths ranging
from 3-130 feet (0.9-39.7 m) The corallites are arranged in long
valleys along with ridges having no top groove.',
'Reef'),
('Siderastrea siderea',
'Massive Starlet Coral',
'Forming rounded heads or boulders up to 4 feet (1.2 m) or more in
diameter, the surface of the massive starlet coral is covered with
round, pitted corallites. These light gray to golden brown uniformly
colored corals inhabit shallow to moderate reefs at depths ranging
from 25-45 feet (7.6-13.7 m). The massive starlet coral prefers clear
water and lives in protected areas of shallow reefs.',
'Reef'),
('Oculina diffusa',
'Ivory Bush Coral',
'Dense branches growing in clumps are characteristic of the diffuse
ivory bush coral. The short branches are crooked with raised
corallites. It appears yellow-brown, commonly encrusted with other
organisms resulting in a varied color appearance. The diffuse ivory
bush coral thrives in areas of high sedimentation including
hardbottoms, lagoons, and back reef areas to depths of 40 feet (12.2
m).',
'Reef');

INSERT INTO certification VALUES
(1,
'Drysuit Diving',
'Advanced Open Water',
'SSI',
'Drysuit diving opens up a world of opportunities, including diving remote Arctic destinations and exploring cold-water dive sites teeming with life. Dry suit diving also keeps you warm on multi-dive days when you do not want to spend your time getting in and out of a cold wetsuit. The SSI Dry Suit Diving specialty program is the best way to become a dry suit diver and teaches you all the knowledge and techniques you need to dive safely and comfortably in a dry suit. You will learn how to use specialized equipment, like dry suits and BCs, the benefits of dry suits and how to deal with dry suit emergencies – which are unique to this type of diving. Upon completion, you will earn the SSI Dry Suit Diving specialty certification.'
),
(2,
'Night Diving',
'Open Water',
'SSI',
'Night diving requires different skills from diving during the day. The SSI Night Diving and Limited Visibility specialty is the best way to learn about night diving and practice the techniques you will need to become a safe and confident night diver. In this program, you will be provided with all the knowledge and skills you need to safely and comfortably dive at night or in limited visibility conditions. With a combination of online learning and open water training dives, you will learn how to enter and exit the water, use specialized equipment, and how to communicate with your buddy easily at night or in limited visibility. Upon completion, you will earn the SSI Night Diving and Limited Visibility specialty certification and be ready to go night diving with confidence.'
),
(3,
'Wreck Diving',
'Open Water',
'SSI',
'Many of the ocean’s best dive sites are wrecks. These impressive structures attract unusually high densities of marine life and give you the chance to immerse in living history as you dive. There is nothing quite like wreck diving and the SSI Wreck Diving specialty will give you all the skills and knowledge you need to become a safe and confident wreck diver. With a combination of academic and confined water sessions, you will be taught how to safely conduct non-penetration dives around wrecks and artificial reefs, up to a depth of 30 meters. You will also get to practice your wreck diving skills during open water training dives. All of which will ensure you can enjoy wreck diving with confidence and get the most out of every dive. Upon completion of this program, you will earn your SSI Wreck Diving specialty certification. Continue your adventures and become a wreck diver. Get started online today!'
),
(4,
'Open Water Diver',
'Beginner',
'SSI',
'This globally recognized certification program is the best way to begin your lifelong adventures as a certified scuba diver. Personalized training is combined with in-water practice sessions to ensure you have the skills and experience required to become truly comfortable underwater. You will earn the SSI Open Water Diver certification.'
),
(5,
'Open Water Instructor',
'Divemaster',
'SSI',
'Do you dream of travelling the world working as a scuba instructor? With this globally recognized certification, you can work at SSI Training Centers represented in over 130 countries. This in-depth program provides all you need to become an SSI Open Water Instructor. Once certified, you can train new SSI divers, teach Enriched Air Nitrox, Diver Stress & Rescue and create Dive Guides. The possibilities are endless, so start your dive career now!'
),
(6,
'Dive Theory',
'Divemaster',
'PADI',
'Dive Theory will dramatically expand your understanding of dive physics, physiology, equipment, decompression theory and dive planning.'
),
(7,
'Open Water Diver',
'Beginner',
'PADI',
'PADI® Open Water Diver is the first scuba certification level. A highly-trained PADI Instructor will teach you how to scuba dive in a relaxed, supportive learning environment.'
),
(8,
'Advanced Open Water Diver',
'Open Water',
'PADI',
'The Advanced Open Water Diver course is all about advancing your skills. Youll practice navigation and buoyancy, try deep diving and make three specialty dives of your choosing (its like a specialty sampler platter). For every specialty dive you complete, you can earn credit toward PADI® specialty certifications.'
),
(9,
'Enriched Air (Nitrox) Diver',
'Open Water',
'PADI',
'Enriched air, also known as nitrox or EANx, contains less nitrogen than regular air. Breathing less nitrogen means you can enjoy longer dives and shorter surface intervals. No wonder Enriched Air Diver is the most popular PADI® specialty.'
),
(10,
'Deep Diver',
'Advanced Open Water',
'PADI',
'During the PADI® Deep Diver course, youll learn how to plan deep dives, manage your gas supply and how to identify and manage narcosis.'
);

INSERT INTO dive_site VALUES
(1,
'SS Copenhagen is a natural wreck, meaning it sank on it’s own so it is declared as a State Underwater Archaeological Preserve. This wreck was a cargo ship carrying coal and ran aground on the Pompano Drop Off reef. Some of this wreck was visible above water so the US Navy used it for target practice in WWII and it currently sits in 30 ft of water in hundreds of pieces. Some areas of interest on this site is the huge ship anchor and the Preserve plaque. This is also a great site for snorkeling because it’s in line with the shallow 15ft reef off Pompano Beach and it accessible by the mooring system.',
'Pompano Beach',
'United States',
'SS Copenhagen',
'26.2055,-80.0851',
'Wreck'
),
(2,
'The Captain Dan was originally commissioned "Hollyhock" (WAGL-220) a 175-foot U.S. Coast Guard buoy tender built in March of 1937 in Milwaukee, Wisconsin. In 1959, she was moved to Detroit, Michigan, where she was used as an ice breaker in Lake Michigan. She later served in Miami, Florida as a buoy tender and in the Bahamas for refueling seaplanes for the U.S. Air Force.',
'Pompano Beach',
'United States',
'Captain Dan',
'26.2310,-80.0660',
'Wreck'
),
(3,
'The Lady Luck is a 324 ft tanker vessel that was sunk on July 23rd, 2016 and is one of the biggest contributions to Florida’s artificial reef system. Originally named the Newtown Creek, the Lady Luck was built in 1967 and operated as a sewage tanker for nearly 50 years, transporting 1.2 million gallons of sewage per day. She was decommissioned in 2014 and sold to Shipwreck Park Inc. in 2016 thanks to contributions from the city of Pompano Beach and Isle Casino Racing Pompano Park. Artist Dennis MacDonald, of Pompano Beach, was hired to create casino themed displays as a part of the Isle Casino Racing Pompano Park sponsorship. Some of the art displays include a mermaid waitress, an octopus dealer, giant dice, and poker table with card sharks (Make sure you have your camera ready to take pictures)',
'Pompano Beach',
'United States',
'Lady Luck',
'26.2307,-80.0632',
'Wreck'
),
(4,
'The Sea Emperor was formerly a hopper barge that was donated as part of a fine levied on a dredging company that destroyed some reef habitat off Palm Beach County. She was filled with large concrete culverts and then sunk off Boca Raton. When the barge sank it flipped, scattering the culverts and landing upside down creating a fantastic playground for fish and divers alike.',
'Boca Raton',
'United States',
'Sea Emperor',
'26.3020,-80.0564',
'Wreck'
),
(5,
'Breakers Reef is one of the most popular reef dives in Palm Beach County. It’s a reef line running North to South in 50-65 ft of water and is a favorite for Open Water certified divers because it’s a great drift dive experience. This reef is named after the Breakers Hotel and many of the boats will drop you on a spot called Fourth Window on this site because its in line with the 4th window on the north section of the hotel. The ledge (5-10 ft in height) on the west side of this reef is the shallowest point and has the most marine life. The backside of this reef to the east is deeper and great for divers wanting to spearfish or lobster. During the Spring and Summer months this site is packed with Loggerhead, Green, or Hawksbill sea turtles.',
'West Palm Beach',
'United States',
'Breakers Reef',
'26.7107,-80.0191',
'Reef'
),
(6,
'This is a famous site where divers can get some Caribbean Reef shark action. Shark Canyon is located on the Juno Ledge Reef and sits in 70-85 ft of water. If its a north running current, when you drop in the site looks like a flat desert to the south. Kick a little north and you will find a horseshoe cut out in a reef ledge in which we call the Amphitheater. This is your target, then you get to this spot you will want to sit down in the sand and wait...the sharks will show up give it at least 10 minutes before you move along the reef. This Amphitheater is great for shark sightings because they swim around the divers without having to have bait in the water, so this is truly a natural shark diving experience. If you decide to swim on from the Amphitheater, there is a second Amphitheater cut out in the reef...again this is a great area to sit down and wait for the sharks to come around. After these two Amphitheaters there is a 4 ft ledge that extends to the North, which has lots of life on it. We tend to see the same green sea turtle and a tagged Hawksbill turtle at this site, so that is always a great experience. Divers in the past have also seen spotted eagle rays and hammerhead sharks on this site. What a great site to visit if you want to do a shark dive without any bait.',
'Juno Beach',
'United States',
'Shark Canyon',
'26.2055,-80.0851',
'Reef'
),
(7,
'The Hydro Atlantic Shipwreck is considered to be one of the 10 best wreck dives in the USA by many. She lies only 1.3 miles southeast of the Boca Inlet, and sits in 173 feet of water. The ship was built for the U.S. Army Corps of Engineers in 1905 by Maryland Steel Corporation and named the Delaware. She was sold in 1950 to Construction Aggregates Corporation and renamed Sand Captain. In 1961, she was once again renamed, this time Ezra Sensibar, after a major rebuild. She was powered by a twin screw diesel electric plant. In 1968 she was sold to Hydromar Corporation and renamed Hydro Atlantic. On her last voyage she was being towed to a Texas salvage yard when the old hull gave out and she sank on December 7, 1987. The Hydro is an advanced dive, and should be performed as a technical dive to get the most out of her. Her deck lies at a depth of 145-150 feet and one mast comes to 120 feet, which makes her accessible by more advanced recreational divers, but this doesnt give a lot of bottom time. Diving her as a tech diver, you can spend 25-30 minutes or more on the wreck and still have only a 60-75 minute runtime. There is frequently a strong current on this dive, and you should expect to see large amberjacks and other pelagic fish on this wreck with an occasional bull shark in the distance.',
'Boca Raton',
'United States',
'Hydro Atlantic',
'26.3250,-80.0507',
'Wreck'
),
(8,
'One of the premiere shore diving locations in all of Florida, the Blue Heron Bridge. It is located on the  Intracoastal Waterway just inside of the Lake Worth Inlet often rated in the top 10 shore dives world!! This site is located inside Phil Foster Park and is just past the Force-E Riviera location. Our staff dives the bridge daily, and our Blue Heron Bridge map is printed up for you to grab for free from the store. Divers should be aware of the tide table to dive this site. The best time to dive the bridge is between an hour before and after high tide. Depths at this site range from about 5 to 20 feet, which makes it ideal for new divers, photographers, and snorkelers.',
'Riviera Beach',
'United States',
'Blue Heron Bridge',
'26.7831,-80.0419',
'Reef'
),
(9,
'From anywhere in the town of Lauderdale-by-the-Sea, you can enter the water, swim out about 100 yards and be on a reef. Many people like entering the water at Datura or Hibiscus streets, which are south of Commercial Boulevard.',
'Lauderdale-by-the-Sea',
'United States',
'Shipwreck Trail',
'26.1872,-80.0934',
'Wreck'
),
(10,
'Along this same reef line is The Nursery. This site got it’s name because there is a family of nurse sharks that like to hang out in the area which makes it fun for all to experience. This site has some great coral & fish life and actually has a very rare coral growth of staghorn coral here. Another fun part about this dive is the Bermuda chubs like to hang out under your boat, which is great for snorkelers.',
'Pompano Beach',
'United States',
'Nursery Reef',
'26.2055,-80.0851',
'Reef'
);

INSERT INTO equipment VALUES
(1,
'Mares',
'X-Tream',
'Mask',
'X-Tream spearfishing mask with ultra-low volume and very wide field of view. X-Tream is an ultra-light, hydrodynamic and minimalist goggle providing incredible vision .'),
(2,
'Mares',
'Ultra ADJ',
'Regulator',
'The Ultra ADJ scuba diver regulator is made of a lightweight technopolymer and weighs just 192g. It incorporates a combination of technology, ensuring maximum breathing comfort. The 82X first stage is forged from brass, chrome-plated and finished with a "pearly" surface. This processing makes it highly resistant to abrasion, while offering a unique and elegant appearance. The Ultra ADJ second stage is pneumatically balanced with the PAD (Pneumatic Assisted Design) system, offering comfortable and effortless breathing in every situation.'),
(3,
'Mares',
'Genius',
'Computer',
'The Mares Genius scuba dive computer is ideal for technical divers who use Trimix and Nitrox mixtures with multiple changes and who may wish to optimise decompression and bottom times depending on the gas supply. The ability to vary decompression according to the gases actually used is a great safety advantage. The colour display is clearly visible in all conditions and the interface menu is intuitive and easy to use thanks to the large buttons.'),
(4,
'Aqualung',
'Xscape',
'Wetsuit',
'The XSCAPE wetsuits offer enhanced comfort for warm waters between 20 and 28°C. Thanks to the flexible and lightweight material, these 4+3mm wetsuits can also be used for snorkeling, freediving, paddling or any other ocean sport you love. These aqualung wetsuits use revolutionary Yulex® instead of neoprene. This composite material is made of a natural rubber core layer, laminated with water-based glue and a fabric made of recycled plastic bottles; our aim was to design the ultimate eco-friendly wetsuit.'),
(5,
'Aqualung',
'Storm',
'Fins',
'The Storm is a great all-around fin ideal for travel. Produced using Monprene, a single material construction gives both durability and strength while maintaining exceptionally light weight, exactly what the traveling diver requires. The innovative foot pocket design has the advantage of a full foot fin for comfort with the versatility of an open-heel fin foradjustments. Available for juniors and adults. Made in Italy'),
(6,
'Aqualung',
'Omni',
'BCD',
'Created for anyone who wants to fully customize their dive gear, the Omni is a revolutionary jacket-style BCD designed to fit your specific style and size. Do not forget to order your color kit when purchasing your OMNI. Bringing ModLock technology popularized by our Rogue & Outlaw BCDs connector system, the Omni allows you to choose from 3 universal sizing components: for your back, your shoulders and your waist, allowing for dozens of size combinations. Continue your customization by choosing from multiple accessory options and 6 color kits. This is the ideal platform to create a personalized BC with perfect fit and your choice of color!'),
(7,
'Scubapro',
'Galileo',
'Computer',
'The Galileo HUD Dive Computer is an innovative mask-mounted, hands-free dive computer designed to keep you fully immersed in your dive, so you can experience more freedom on your dive. Featuring a virtual, floating heads-up display that uses precision near-eye optics, it keeps your essential dive information right in front of you. Using the intuitive push-wheel knob, you can quickly navigate the customizable menu without having to look away, and the screen conveniently tilts up and out of the way before or after a dive, or any time you don’t need it. With the Galileo HUD, your dive data’s never looked so good.'),
(8,
'Scubapro',
'Level',
'BCD',
'A fresh design incorporating eye-catching silver, blue and white graphics make the Level BCD stand out in any diving crowd. But beyond good looks, this front-adjustable BCD brings together all of the performance and comfort features you’ll need for any recreational diving scenario. The bladder, made of EndurTex high-tenacity 420 nylon fabric, is lightweight yet extremely rugged, and it’s designed to comfortably wrap around your body without squeeze. Rotating quick-release shoulder buckles allow you to optimize the routing of your shoulder straps for comfort, and a sternum strap and adjustable cummerbund with double-pull over-strap make for the perfect fit.'),
(9,
'Scubapro',
'MK11 / S270',
'Regulator',
'For divers seeking reliable performance in an uncomplicated air delivery system, the MK11 / S270 is easy to use, compact and durable. The balanced diaphragm MK11 delivers effortless airflow unaffected by depth, tank pressure or breathing rate. The compact S270 provides smooth breathing performance in a bulletproof anti-scratch design that’s able to handle years of hard use.'),
(10,
'Koah',
'Shortie',
'Speargun',
'Best way to describe it would be " The Pistol of KOAH spearguns". Ranging from 28-38 inches in size, the primary function of the shortie is to wedge in places others cannot. Servers as a great hole gun as well as an easy to carry speargun when lobstering.  Very popular in the Keys where hog-fish and snapper are common. Comes stock with a stout 8mm shaft and (2) 5/8 bands to give you an effective 12-14ft of accurate range. Maximum band stretch is utilized by placing the handle and trigger mechanism at the farthest rear placement point.');

INSERT INTO dive_center VALUES
(1,
'Aqualife Divers',
'Florida',
'Pompano Beach',
'2705 N Riverside Dr',
'33062',
'(954) 231-3483'
),
(2,
'South Florida Diving Headquarters',
'Florida',
'Pompano Beach',
'101 N Riverside Dr #111',
'33062',
'(954) 783-2299'
),
(3,
'Force-E Scuba Center',
'Florida',
'Boca Raton',
'2621 N Federal Hwy',
'33431',
'(561) 368-0555'
),
(4,
'Pineapple SCUBA',
'Florida',
'Fort Lauderdale',
'2935 N Federal Hwy',
'33306',
'(954) 514-7235'
);

INSERT INTO certifications_offered VALUES
(1,
10,
311
),
(3,
7,
245
),
(4,
4,
272
),
(2,
5,
365
),
(4,
9,
206
),
(1,
1,
120
),
(4,
6,
257
),
(2,
8,
132
),
(3,
2,
101
),
(2,
3,
362
),
(3,
8,
271
),
(2,
9,
326
),
(3,
1,
351
);

INSERT INTO user VALUES
(1,
'male',
'718-313-7652',
'United States',
'Open Water',
'Florida', 
'33431',
'Boca Raton',
'2296 NW 36th St',
'matthewaaa123@gmail.com',
'Matthew',
'Acs',
"2004-04-07",
2020,
'I like to dive wrecks in South Florida',
1
),
(2,
'male',
'718-200-6780',
'United States',
'Advanced Open Water',
'Florida', 
'33431',
'Boca Raton',
'2296 NW 36th St',
'richardaaa321@gmail.com',
'Richard',
'Acs',
"2004-04-07",
2020,
'I like to go very very deep',
2
),
(3,
'male',
'718-313-7469',
'United States',
'Master Diver',
'Florida', 
'33431',
'Boca Raton',
'2296 NW 36th St',
'levyacs@gmail.com',
'Levy',
'Acs',
"1972-01-18",
2020,
'Diving reefs is very relaxing',
4
),
(4,
'male',
'785-404-2479',
'United States',
'Open Water',
'New York', 
'11357',
'Franklin Square',
'9636 SE 30th Blvd',
'agavalas@gmail.com',
'Andreas',
'Gavalas',
"2003-08-21",
2021,
'Chess is even more fun underwater',
4
),
(5,
'male',
'916-413-7519',
'United States',
'Dive Instructor',
'Florida', 
'33060',
'Pompano Beach',
'33134 Rusty Hook Blvd',
'smurfdiver@gmail.com',
'Attila',
'Kutas',
"1974-08-23",
1989,
'100 ft visibility, calm water, lots of bugs!',
1
);

INSERT INTO dive_buddy VALUES
(1,
2,
2020
),
(2,
1,
2021
),
(3,
4,
2021
),
(3,
2,
2022
),
(3,
1,
2022
),
(4,
1,
2022
),
(4,
2,
2022
),
(1,
4,
2022
),
(3,
5,
2020
),
(5,
3,
2020
);

INSERT INTO equipment_owned VALUES
(1,
1,
'2019-08-12',
220,
'2020-04-04',
'Sketchy but fun'
),
(3,
1,
'2019-08-12',
624,
'2020-04-04',
'Very easy to use'
),
(2,
2,
'2020-04-04',
20,
'2020-08-14',
'Comfortable'
),
(3,
3,
'2000-09-01',
120,
'2020-01-21',
'Scratchy in places'
),
(4,
4,
'2010-02-02',
999,
'2020-04-04',
'Like a cloud'
),
(5,
4,
'2016-09-11',
850,
'2020-04-04',
'Straps do not stay on well'
),
(7,
4,
'2016-09-11',
1150,
'2020-04-04',
'Feel very high tech'
),
(8,
1,
'2012-02-11',
723,
'2022-01-22',
'Extremely fast'
),
(10,
3,
'2021-03-19',
500,
'2021-03-19',
'Light weight and ultra durable'
);

INSERT INTO user_certification VALUES
(1,
4,
'2020-02-02',
22171
),
(2,
4,
'2020-03-12',
12563
),
(3,
4,
'2020-05-22',
34544
),
(4,
4,
'2021-01-11',
98978
),
(1,
2,
'2021-08-12',
212454
),
(3,
8,
'2021-01-19',
923431
),
(2,
8,
'2021-07-29',
9512243
),
(3,
10,
'2021-01-01',
112343
),
(1,
9,
'2022-02-01',
6632456
);

INSERT INTO dive VALUES
(1,
1,
'Calm',
'00:30:00',
'Air',
'2020-02-02',
80,
85,
36,
'Diving is scary at first!',
1,
1
),
(2,
1,
'Choppy',
'00:35:00',
'Air',
'2020-02-08',
79,
83,
20,
'I just want to dive deeper, I dont know why they limit me to 20 feet!',
1,
2
),
(3,
23,
'Calm',
'00:42:00',
'Trimix',
'2021-11-08',
77,
80,
150,
'The Hydro Atlantic is much bigger than I thought.',
7,
3
),
(4,
10,
'Choppy',
'01:10:00',
'Nitrox-38',
'2022-01-28',
75,
68,
70,
'I saw two awesome tiger sharks and bull sharks',
6,
4
),
(5,
13,
'Calm',
'00:10:00',
'Nitrox-40',
'2021-09-22',
79,
81,
15,
'I got bored really fast',
10,
2
),
(6,
9,
'Choppy',
'00:46:00',
'Nitrox-25',
'2021-12-01',
85,
89,
90,
'I did not bring enough weight, I kept floaitng up',
9,
1
),
(7,
9,
'Calm',
'00:55:00',
'Nitrox-29',
'2021-8-04',
85,
93,
86,
'I lost track of time and nearly ran out of air',
3,
3
),
(8,
14,
'Calm',
'00:19:00',
'Air',
'2022-2-07',
81,
92,
90,
'I colud only see the top of the wreck, why did the dive operator let me on this trip?',
7,
4
);

INSERT INTO fauna_seen VALUES
('Chelonia mydas',
1,
'My first sea turtle! They are alot smaller than I hoped'
),
('Epinephelus itajara',
2,
'It grunted at me'
),
('Ginglymostoma cirratum',
3,
'My first shark! Took long enough'
),
('Lachnolaimus maximus',
4,
'Free dinner tonight'
),
('Octopus briareus',
5,
'It looked like a rock'
),
('Panulirus argus',
6,
'They look like bugs'
),
('Pomacanthus paru',
7,
'Very exotic looking'
),
('Pterois volitans',
8,
'I almost touched it, twice'
);

INSERT INTO flora_seen VALUES
('Acropora cervicornis',
1,
'There was a lot of coral on the dive'
),
('Avicennia germinans',
2,
'I saw the mangroves over at the dock'
),
('Diploria strigosa',
3,
'I have never seen this type of coral in Florida before'
),
('Gorgonia ventalina',
4,
'I did not think it would be as large as it was'
),
('Halodule wrightii',
5,
'It reminded me of a green pasture'
),
('Oculina diffusa',
6,
'Looks similar to the staghorn coral'
),
('Sargassum natans',
7,
'The seaweed covered the surface on decent'
),
('Siderastrea siderea',
8,
'It really is true to its name'
);









